#!/bin/bash
# 解压后双击运行（包内已带可执行权限位）
# 若系统仍提示没有权限：终端 cd 到本目录执行  chmod +x 启动工作台.command app/启动教师端.command
cd "$(dirname "$0")"
exec ./app/启动教师端.command "$@"
