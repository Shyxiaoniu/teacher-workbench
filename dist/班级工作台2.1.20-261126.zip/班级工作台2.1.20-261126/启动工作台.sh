#!/bin/bash
# 解压后执行： bash 启动工作台.sh
# 想后台常驻 / 开机自启，见 README「四、部署 → 无外网服务器」里的 systemd 示例。
cd "$(dirname "$0")" || exit 1
exec ./app/启动教师端.sh "$@"
