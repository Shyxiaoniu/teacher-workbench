#!/bin/bash
# 解压后双击运行；首次可能需要 chmod +x 启动工作台.command
cd "$(dirname "$0")"
exec ./app/启动教师端.command "$@"
